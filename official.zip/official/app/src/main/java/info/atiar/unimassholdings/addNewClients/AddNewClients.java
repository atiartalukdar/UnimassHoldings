package info.atiar.unimassholdings.addNewClients;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import info.atiar.unimassholdings.R;

public class AddNewClients extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_clients);
    }
}
